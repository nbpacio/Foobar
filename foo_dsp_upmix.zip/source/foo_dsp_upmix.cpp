/*******************************************************************************
*                                                                              *
* foo_dsp_upmix                                                                *
* Copyleft 2008 Hancoque (hancoque@gmx.de)                                     *
*                                                                              *
* This program is free software; you can redistribute it and/or modify         *
* it under the terms of the GNU General Public License as published by         *
* the Free Software Foundation; either version 2 of the License, or            *
* (at your option) any later version.                                          *
*                                                                              *
* This program is distributed in the hope that it will be useful,              *
* but WITHOUT ANY WARRANTY; without even the implied warranty of               *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
* GNU General Public License for more details.                                 *
*                                                                              *
* You should have received a copy of the GNU General Public License            *
* along with this program; if not, write to the Free Software                  *
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    *
*                                                                              *
*******************************************************************************/

#include <sstream>
#include "foo_dsp_upmix.h"

DECLARE_COMPONENT_VERSION(
	"2ch to 6ch",
	"1.1",
	"foo_dsp_upmix\n"
	"Copyleft 2008 Hancoque\n"
	"Based on Moitah's Center Cut plugin."
	);

class foo_dsp_upmix1 : public dsp_impl_base
{
private:
	CenterCut *_cc;
	int _sampleRate;
	int _bufferedSamples;

public:
	foo_dsp_upmix1()
	{
		_cc = new CenterCut(true);
		_bufferedSamples = 0;
	}

	~foo_dsp_upmix1()
	{
		delete _cc;
	}

	static GUID g_get_guid()
	{
		static const GUID guid = { 0x62d14d01, 0xeb11, 0x493c, { 0xb8, 0x13, 0xd9, 0x3c, 0xf, 0x92, 0xc2, 0x23 } };
		return guid;
	}

	static void g_get_name(pfc::string_base & p_out)
	{
		p_out = "2ch to 6ch (double center)";
	}

	virtual bool on_chunk(audio_chunk * inChunk, abort_callback &)
	{
		_sampleRate = inChunk->get_sample_rate();

		if (inChunk->get_channels() != 2)
		{
			return true;
		}

		const audio_sample *inSamples = inChunk->get_data();
		int inSampleCount = inChunk->get_sample_count();

		while (inSampleCount > 0)
		{
			int copyCount = min(inSampleCount, _cc->GetInputSamplesNeeded());
			double *ccInput = _cc->GetInputBuffer();

			for (int i = 0; i < copyCount; i++)
			{
				ccInput[0] = (double)inSamples[0];
				ccInput[1] = (double)inSamples[1];
				ccInput += 2;
				inSamples += 2;
			}

			inSampleCount -= copyCount;
			_bufferedSamples += copyCount;

			if (_cc->ProcessSamples(copyCount))
			{
				OutputSamples(_cc->GetOutputBuffer(), _cc->GetOutputLength());
			}
		}

		return false;
	}

	virtual void flush()
	{
		_cc->Flush();
		_bufferedSamples = 0;
	}

	virtual void on_endoftrack(abort_callback &)
	{
		FlushToOutput();
	}

	virtual void on_endofplayback(abort_callback &)
	{
		FlushToOutput();
	}

	virtual double get_latency()
	{
		return ((double)_bufferedSamples / (double)_sampleRate);
	}

	virtual bool need_track_change_mark()
	{
		return false;
	}

private:
	void FlushToOutput()
	{
		int outSampleCount;

		while ((outSampleCount = _cc->FlushWithReturn()) != -1)
		{
			if (outSampleCount > 0)
			{
				OutputSamples(_cc->GetOutputBuffer(), outSampleCount);
			}
		}
	}

	void OutputSamples(double *ccOutput, int outSampleCount)
	{
		audio_chunk *outChunk;
		audio_sample *outSamples;

		outChunk = insert_chunk(outSampleCount);
		outChunk->set_data_size(outSampleCount * 6);
		outChunk->set_sample_count(outSampleCount);
		outChunk->set_channels(6);
		outChunk->set_sample_rate(_sampleRate);
		outSamples = outChunk->get_data();

		double *ccInput = _cc->GetInputBuffer();

		for (int i = 0; i < outSampleCount; i++)
		{
			outSamples[0] = (audio_sample)(ccInput[0] - ccOutput[0]); // Lf
			outSamples[1] = (audio_sample)(ccInput[1] - ccOutput[0]); // Rf
			outSamples[2] = (audio_sample)(ccOutput[0] * 4.0); // C
			outSamples[3] = 0.0f; // LFE (empty)
			outSamples[4] = (audio_sample)(ccInput[0] - ccOutput[0]); // Ls
			outSamples[5] = (audio_sample)(ccInput[1] - ccOutput[0]); // Rs

			outSamples += 6;
			ccOutput += 2;
			ccInput += 2;
		}

		_bufferedSamples -= outSampleCount;
	}
};


class foo_dsp_upmix2 : public dsp_impl_base
{
private:
	CenterCut *_cc;
	int _sampleRate;
	int _bufferedSamples;

public:
	foo_dsp_upmix2()
	{
		_cc = new CenterCut(true);
		_bufferedSamples = 0;
	}

	~foo_dsp_upmix2()
	{
		delete _cc;
	}

	static GUID g_get_guid()
	{
		static const GUID guid = { 0xc4df7f2f, 0xbeab, 0x4074, { 0x9c, 0x8d, 0x5e, 0x69, 0xfa, 0x70, 0xb, 0x4c } };
		return guid;
	}

	static void g_get_name(pfc::string_base & p_out)
	{
		p_out = "2ch to 6ch (full rear)";
	}

	virtual bool on_chunk(audio_chunk * inChunk, abort_callback &)
	{
		_sampleRate = inChunk->get_sample_rate();

		if (inChunk->get_channels() != 2)
		{
			return true;
		}

		const audio_sample *inSamples = inChunk->get_data();
		int inSampleCount = inChunk->get_sample_count();

		while (inSampleCount > 0)
		{
			int copyCount = min(inSampleCount, _cc->GetInputSamplesNeeded());
			double *ccInput = _cc->GetInputBuffer();

			for (int i = 0; i < copyCount; i++)
			{
				ccInput[0] = (double)inSamples[0];
				ccInput[1] = (double)inSamples[1];
				ccInput += 2;
				inSamples += 2;
			}

			inSampleCount -= copyCount;
			_bufferedSamples += copyCount;

			if (_cc->ProcessSamples(copyCount))
			{
				OutputSamples(_cc->GetOutputBuffer(), _cc->GetOutputLength());
			}
		}

		return false;
	}

	virtual void flush()
	{
		_cc->Flush();
		_bufferedSamples = 0;
	}

	virtual void on_endoftrack(abort_callback &)
	{
		FlushToOutput();
	}

	virtual void on_endofplayback(abort_callback &)
	{
		FlushToOutput();
	}

	virtual double get_latency()
	{
		return ((double)_bufferedSamples / (double)_sampleRate);
	}

	virtual bool need_track_change_mark()
	{
		return false;
	}

private:
	void FlushToOutput()
	{
		int outSampleCount;

		while ((outSampleCount = _cc->FlushWithReturn()) != -1)
		{
			if (outSampleCount > 0)
			{
				OutputSamples(_cc->GetOutputBuffer(), outSampleCount);
			}
		}
	}

	void OutputSamples(double *ccOutput, int outSampleCount)
	{
		audio_chunk *outChunk;
		audio_sample *outSamples;

		outChunk = insert_chunk(outSampleCount);
		outChunk->set_data_size(outSampleCount * 6);
		outChunk->set_sample_count(outSampleCount);
		outChunk->set_channels(6);
		outChunk->set_sample_rate(_sampleRate);
		outSamples = outChunk->get_data();

		double *ccInput = _cc->GetInputBuffer();

		for (int i = 0; i < outSampleCount; i++)
		{
			outSamples[0] = (audio_sample)(ccInput[0] - ccOutput[0]); // Lf
			outSamples[1] = (audio_sample)(ccInput[1] - ccOutput[0]); // Rf
			outSamples[2] = (audio_sample)(ccOutput[0] * 2.0); // C
			outSamples[3] = 0.0f; // LFE (empty)
			outSamples[4] = (audio_sample)ccInput[0]; // Ls
			outSamples[5] = (audio_sample)ccInput[1]; // Rs

			outSamples += 6;
			ccOutput += 2;
			ccInput += 2;
		}

		_bufferedSamples -= outSampleCount;
	}
};


class foo_dsp_upmix3 : public dsp_impl_base
{
private:
	CenterCut *_cc;
	int _sampleRate;
	int _bufferedSamples;

public:
	foo_dsp_upmix3()
	{
		_cc = new CenterCut(true);
		_bufferedSamples = 0;
	}

	~foo_dsp_upmix3()
	{
		delete _cc;
	}

	static GUID g_get_guid()
	{
		static const GUID guid = { 0xa89fe527, 0x2b00, 0x42b5, { 0xae, 0xfb, 0xfc, 0x5c, 0xcd, 0xac, 0x2f, 0x83 } };
		return guid;
	}

	static void g_get_name(pfc::string_base & p_out)
	{
		p_out = "2ch to 6ch (full front)";
	}

	virtual bool on_chunk(audio_chunk * inChunk, abort_callback &)
	{
		_sampleRate = inChunk->get_sample_rate();

		if (inChunk->get_channels() != 2)
		{
			return true;
		}

		const audio_sample *inSamples = inChunk->get_data();
		int inSampleCount = inChunk->get_sample_count();

		while (inSampleCount > 0)
		{
			int copyCount = min(inSampleCount, _cc->GetInputSamplesNeeded());
			double *ccInput = _cc->GetInputBuffer();

			for (int i = 0; i < copyCount; i++)
			{
				ccInput[0] = (double)inSamples[0];
				ccInput[1] = (double)inSamples[1];
				ccInput += 2;
				inSamples += 2;
			}

			inSampleCount -= copyCount;
			_bufferedSamples += copyCount;

			if (_cc->ProcessSamples(copyCount))
			{
				OutputSamples(_cc->GetOutputBuffer(), _cc->GetOutputLength());
			}
		}

		return false;
	}

	virtual void flush()
	{
		_cc->Flush();
		_bufferedSamples = 0;
	}

	virtual void on_endoftrack(abort_callback &)
	{
		FlushToOutput();
	}

	virtual void on_endofplayback(abort_callback &)
	{
		FlushToOutput();
	}

	virtual double get_latency()
	{
		return ((double)_bufferedSamples / (double)_sampleRate);
	}

	virtual bool need_track_change_mark()
	{
		return false;
	}

private:
	void FlushToOutput()
	{
		int outSampleCount;

		while ((outSampleCount = _cc->FlushWithReturn()) != -1)
		{
			if (outSampleCount > 0)
			{
				OutputSamples(_cc->GetOutputBuffer(), outSampleCount);
			}
		}
	}

	void OutputSamples(double *ccOutput, int outSampleCount)
	{
		audio_chunk *outChunk;
		audio_sample *outSamples;

		outChunk = insert_chunk(outSampleCount);
		outChunk->set_data_size(outSampleCount * 6);
		outChunk->set_sample_count(outSampleCount);
		outChunk->set_channels(6);
		outChunk->set_sample_rate(_sampleRate);
		outSamples = outChunk->get_data();

		double *ccInput = _cc->GetInputBuffer();

		for (int i = 0; i < outSampleCount; i++)
		{
			outSamples[0] = (audio_sample)ccInput[0]; // Lf
			outSamples[1] = (audio_sample)ccInput[1]; // Rf
			outSamples[2] = (audio_sample)(ccOutput[0] * 2.0); // C
			outSamples[3] = 0.0f; // LFE (empty)
			outSamples[4] = (audio_sample)(ccInput[0] - ccOutput[0]); // Ls
			outSamples[5] = (audio_sample)(ccInput[1] - ccOutput[0]); // Rs

			outSamples += 6;
			ccOutput += 2;
			ccInput += 2;
		}

		_bufferedSamples -= outSampleCount;
	}
};


static dsp_factory_nopreset_t<foo_dsp_upmix1> df_foo_dsp_upmix1;
static dsp_factory_nopreset_t<foo_dsp_upmix2> df_foo_dsp_upmix2;
static dsp_factory_nopreset_t<foo_dsp_upmix3> df_foo_dsp_upmix3;