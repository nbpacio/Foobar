/*******************************************************************************
*                                                                              *
* foo_dsp_centercut                                                            *
* Copyright (C) 2006  Moitah (moitah@yahoo.com)                                *
*                                                                              *
* This program is free software; you can redistribute it and/or modify         *
* it under the terms of the GNU General Public License as published by         *
* the Free Software Foundation; either version 2 of the License, or            *
* (at your option) any later version.                                          *
*                                                                              *
* This program is distributed in the hope that it will be useful,              *
* but WITHOUT ANY WARRANTY; without even the implied warranty of               *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                *
* GNU General Public License for more details.                                 *
*                                                                              *
* You should have received a copy of the GNU General Public License            *
* along with this program; if not, write to the Free Software                  *
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA    *
*                                                                              *
*******************************************************************************/

typedef signed __int64		sint64;
typedef unsigned __int64	uint64;
typedef signed int			sint32;
typedef unsigned int		uint32;
typedef signed short		sint16;
typedef unsigned short		uint16;
typedef signed char			sint8;
typedef unsigned char		uint8;

typedef sint64				int64;
typedef sint32				int32;
typedef sint16				int16;
typedef sint8				int8;

#include <math.h>
#include "../SDK/foobar2000.h"
#include "../helpers/helpers.h"

const double twopi = 6.283185307179586476925286766559;
const double invsqrt2 = 0.70710678118654752440084436210485;
const double nodivbyzero = 0.000000000000001;
const double ccscale = 32768.0;
const double ccscaleinv = 1.0 / 32768.0;

const int kWindowSize = 8192;
const int kOverlapCount = 4;
const int kPostWindowPower = 2;
const int kHalfWindow = kWindowSize / 2;
const int kOverlapSize = kWindowSize / kOverlapCount;

class CenterCut {
public:
	CenterCut(bool outputCenter) {
		mOutputCenter = outputCenter;
		Start();
	}

	~CenterCut() {
		Finish();
	}

	bool ProcessSamples(int sampleCount) {
		mInputPos = (mInputPos + sampleCount) & (kWindowSize - 1);
		mInputSamplesNeeded -= sampleCount;

		if (mInputSamplesNeeded == 0) {
			Run();
			if (mOutputDiscardBlocks == 0) {
				return true;
			}
			else {
				mOutputDiscardBlocks--;
			}
		}

		return false;
	}

	int FlushWithReturn() {
		double zeroBuff[kOverlapSize][2];
		int returnCount;

		memset(zeroBuff, 0, sizeof(zeroBuff));

		if (!mFlushing) {
			mFlushing = true;
			mFlushSamplesRemaining = kWindowSize - mInputSamplesNeeded;
		}
		else if (mFlushSamplesRemaining <= 0) {
			Flush();
			return -1;
		}

		memcpy(&mInput[mInputPos][0], &zeroBuff[0][0], mInputSamplesNeeded * 2 * sizeof(double));
		if (ProcessSamples(mInputSamplesNeeded)) {
			returnCount = min(mFlushSamplesRemaining, kOverlapSize);
		}
		else {
			returnCount = 0;
		}
		mFlushSamplesRemaining -= mInputSamplesNeeded;

		return returnCount;
	}

	void Flush() {
		mFlushing = false;
		mInputPos = 0;
		mInputSamplesNeeded = kOverlapSize;
		mOutputDiscardBlocks = kOverlapCount - 1;
	}

	double *GetInputBuffer() {
		return &mInput[mInputPos][0];
	}

	int GetInputSamplesNeeded() {
		return mInputSamplesNeeded;
	}

	double *GetOutputBuffer() {
		return &mOutput[0][0];
	}

	int GetOutputLength() {
		return kOverlapSize;
	}

private:
	bool			mOutputCenter;
	bool			mFlushing;
	int				mFlushSamplesRemaining;
	int				mOutputDiscardBlocks;
	uint32			mInputSamplesNeeded;
	uint32			mInputPos;
	unsigned		mBitRev[kWindowSize];
	double			mPreWindow[kWindowSize];
	double			mPostWindow[kWindowSize];
	double			mSineTab[kWindowSize];
	double			mInput[kWindowSize][2];
	double			mOutput[kOverlapSize][2];
	double			mOverlapC[kOverlapCount-1][kOverlapSize];
	double			mTempLBuffer[kWindowSize];
	double			mTempRBuffer[kWindowSize];
	double			mTempCBuffer[kWindowSize];

	unsigned IntegerLog2(unsigned v) {
		unsigned i = 0;

		while(v>1) {
			++i;
			v >>= 1;
		}

		return i;
	}

	unsigned RevBits(unsigned x, unsigned bits) {
		unsigned y = 0;

		while(bits--) {
			y = (y+y) + (x&1);
			x >>= 1;
		}

		return y;
	}

	void VDCreateRaisedCosineWindow(double *dst, int n, double power) {
		const double twopi_over_n = twopi / n;
		const double scalefac = 1.0 / n;

		for(int i=0; i<n; ++i) {
			dst[i] = scalefac * pow(0.5*(1.0 - cos(twopi_over_n * (i+0.5))), power);
		}
	}

	void VDCreateHalfSineTable(double *dst, int n) {
		const double twopi_over_n = twopi / n;

		for(int i=0; i<n; ++i) {
			dst[i] = sin(twopi_over_n * i);
		}
	}

	void VDCreateBitRevTable(unsigned *dst, int n) {
		unsigned bits = IntegerLog2(n);

		for(int i=0; i<n; ++i) {
			dst[i] = RevBits(i, bits);
		}
	}

	void CreatePostWindow(double *dst, int windowSize, int power) {
		const double powerIntegrals[8] = { 1.0, 1.0/2.0, 3.0/8.0, 5.0/16.0, 35.0/128.0,
										   63.0/256.0, 231.0/1024.0, 429.0/2048.0 };
		const double scalefac = (double)windowSize * (powerIntegrals[1] / powerIntegrals[power+1]);

		VDCreateRaisedCosineWindow(dst, windowSize, (double)power);

		for(int i=0; i<windowSize; ++i) {
			dst[i] *= scalefac;
		}
	}

	void VDComputeFHT(double *A, int nPoints, const double *sinTab) {
		int i, n, n2, theta_inc;

		// FHT - stage 1 and 2 (2 and 4 points)

		for(i=0; i<nPoints; i+=4) {
			const double	x0 = A[i];
			const double	x1 = A[i+1];
			const double	x2 = A[i+2];
			const double	x3 = A[i+3];

			const double	y0 = x0+x1;
			const double	y1 = x0-x1;
			const double	y2 = x2+x3;
			const double	y3 = x2-x3;

			A[i]	= y0 + y2;
			A[i+2]	= y0 - y2;

			A[i+1]	= y1 + y3;
			A[i+3]	= y1 - y3;
		}

		// FHT - stage 3 (8 points)

		for(i=0; i<nPoints; i+= 8) {
			double alpha, beta;

			alpha	= A[i+0];
			beta	= A[i+4];

			A[i+0]	= alpha + beta;
			A[i+4]	= alpha - beta;

			alpha	= A[i+2];
			beta	= A[i+6];

			A[i+2]	= alpha + beta;
			A[i+6]	= alpha - beta;

			alpha	= A[i+1];

			const double beta1 = invsqrt2*(A[i+5] + A[i+7]);
			const double beta2 = invsqrt2*(A[i+5] - A[i+7]);

			A[i+1]	= alpha + beta1;
			A[i+5]	= alpha - beta1;

			alpha	= A[i+3];

			A[i+3]	= alpha + beta2;
			A[i+7]	= alpha - beta2;
		}

		n = 16;
		n2 = 8;
		theta_inc = nPoints >> 4;

		while(n <= nPoints) {
			for(i=0; i<nPoints; i+=n) {
				int j;
				int theta = theta_inc;
				double alpha, beta;
				const int n4 = n2>>1;

				alpha	= A[i];
				beta	= A[i+n2];

				A[i]	= alpha + beta;
				A[i+n2]	= alpha - beta;

				alpha	= A[i+n4];
				beta	= A[i+n2+n4];

				A[i+n4]		= alpha + beta;
				A[i+n2+n4]	= alpha - beta;

				for(j=1; j<n4; j++) {
					double	sinval	= sinTab[theta];
					double	cosval	= sinTab[theta + (nPoints>>2)];

					double	alpha1	= A[i+j];
					double	alpha2	= A[i-j+n2];
					double	beta1	= A[i+j+n2]*cosval + A[i-j+n ]*sinval;
					double	beta2	= A[i+j+n2]*sinval - A[i-j+n ]*cosval;

					theta	+= theta_inc;

					A[i+j]		= alpha1 + beta1;
					A[i+j+n2]	= alpha1 - beta1;
					A[i-j+n2]	= alpha2 + beta2;
					A[i-j+n]	= alpha2 - beta2;
				}
			}

			n *= 2;
			n2 *= 2;
			theta_inc >>= 1;
		}
	}

	bool Start() {
		mFlushing = false;

		VDCreateBitRevTable(mBitRev, kWindowSize);
		VDCreateHalfSineTable(mSineTab, kWindowSize);

		mInputSamplesNeeded = kOverlapSize;
		mInputPos = 0;

		mOutputDiscardBlocks = kOverlapCount - 1;

		memset(mInput, 0, sizeof mInput);
		memset(mOverlapC, 0, sizeof mOverlapC);

		double *tmp = new double[kWindowSize];
		if (!tmp) return false;
		VDCreateRaisedCosineWindow(tmp, kWindowSize, 1.0);
		for(unsigned i=0; i<kWindowSize; ++i) {
			// The correct Hartley<->FFT conversion is:
			//
			//	Fr(i) = 0.5(Hr(i) + Hi(i))
			//	Fi(i) = 0.5(Hr(i) - Hi(i))
			//
			// We omit the 0.5 in both the forward and reverse directions,
			// so we have a 0.25 to put here.

			mPreWindow[i] = tmp[mBitRev[i]] * (2.0 / (double)kOverlapCount) * 0.5 * ccscale;
		}
		delete[] tmp;

		CreatePostWindow(mPostWindow, kWindowSize, kPostWindowPower);

		return true;
	}

	void Finish() {
	}

	bool Run() {
		unsigned i;

		// copy to temporary buffer and FHT

		for(i=0; i<kWindowSize; ++i) {
			const unsigned j = mBitRev[i];
			const unsigned k = (j + mInputPos) & (kWindowSize-1);
			const double w = mPreWindow[i];

			mTempLBuffer[i] = mInput[k][0] * w;
			mTempRBuffer[i] = mInput[k][1] * w;
		}

		VDComputeFHT(mTempLBuffer, kWindowSize, mSineTab);
		VDComputeFHT(mTempRBuffer, kWindowSize, mSineTab);

		// perform stereo separation

		mTempCBuffer[0] = 0;
		mTempCBuffer[1] = 0;
		for(i=1; i<kHalfWindow; i++) {
			double lR = mTempLBuffer[i] + mTempLBuffer[kWindowSize-i];
			double lI = mTempLBuffer[i] - mTempLBuffer[kWindowSize-i];
			double rR = mTempRBuffer[i] + mTempRBuffer[kWindowSize-i];
			double rI = mTempRBuffer[i] - mTempRBuffer[kWindowSize-i];

			double cR, cI;
			double A, B, C, D;

			cR = lR + rR;
			cI = lI + rI;

			A = cR*cR + cI*cI;
			B = -cR*(lR+rR)-cI*(lI+rI);
			C = lR*rR+lI*rI;
			D = B*B-4*A*C;

			if (D>=0.0 && A>nodivbyzero) {
				double alpha = (-B-sqrt(D))/(2*A);

				cR*=alpha;
				cI*=alpha;
			} else
				cR = cI = 0.0;

			unsigned d1 = mBitRev[i];
			unsigned d2 = mBitRev[kWindowSize-i];

			mTempCBuffer[d1] = cR + cI;
			mTempCBuffer[d2] = cR - cI;
		}

		// reconstitute left/right/center channels

		VDComputeFHT(mTempCBuffer, kWindowSize, mSineTab);

		// apply post-window

		for (i=0; i<kWindowSize; i++) {
			mTempCBuffer[i] *= mPostWindow[i];
		}

		// writeout

		for(i=0; i<kOverlapSize; ++i) {
			int currentBlockIndex, nextBlockIndex, blockOffset;

			double c = (mOverlapC[0][i] + mTempCBuffer[i]) * ccscaleinv;
			double l = mInput[mInputPos+i][0] - c;
			double r = mInput[mInputPos+i][1] - c;

			if (mOutputCenter) {
				mOutput[i][0] = c;
			}
			else {
				mOutput[i][0] = l;
				mOutput[i][1] = r;
			}

			// overlapping

			currentBlockIndex = 0;
			nextBlockIndex = 1;
			blockOffset = kOverlapSize;
			while (nextBlockIndex < kOverlapCount - 1) {
				mOverlapC[currentBlockIndex][i] = mOverlapC[nextBlockIndex][i] +
					mTempCBuffer[blockOffset + i];
				
				currentBlockIndex++;
				nextBlockIndex++;
				blockOffset += kOverlapSize;
			}
			mOverlapC[currentBlockIndex][i] = mTempCBuffer[blockOffset + i];
		}

		mInputSamplesNeeded = kOverlapSize;

		return true;
	}
};